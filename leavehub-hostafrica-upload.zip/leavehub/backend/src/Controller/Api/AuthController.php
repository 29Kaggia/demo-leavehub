<?php
declare(strict_types=1);

namespace App\Controller\Api;

use App\Controller\AppController;
use Cake\Http\Exception\BadRequestException;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\UnauthorizedException;
use Cake\Http\Exception\BadRequestException as UnprocessableEntityException;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

class AuthController extends AppController
{
    public function options(): \Cake\Http\Response
    {
        return $this->json(['data' => ['signup_enabled' => (bool)Configure::read('Auth.allowSignup', true)]]);
    }

    public function signup(): \Cake\Http\Response
    {
        $this->request->allowMethod(['post']);
        if (!Configure::read('Auth.allowSignup', true)) {
            throw new ForbiddenException('Account creation is disabled. Contact your HR administrator.');
        }
        $data = $this->request->getData();
        $required = ['first_name', 'last_name', 'email', 'password'];
        foreach ($required as $field) {
            if (!trim((string)($data[$field] ?? ''))) {
                throw new UnprocessableEntityException(ucwords(str_replace('_', ' ', $field)) . ' is required.');
            }
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            throw new UnprocessableEntityException('Enter a valid email address.');
        }
        if (strlen((string)$data['password']) < 8) {
            throw new UnprocessableEntityException('Your password must have at least 8 characters.');
        }
        $employees = TableRegistry::getTableLocator()->get('Employees');
        $existing = $employees->find()->where([
            'email' => strtolower(trim((string)$data['email'])),
        ])->first();
        if ($existing) {
            throw new UnprocessableEntityException('An account with that email already exists.');
        }
        $employee = $employees->newEntity([
            'employee_number' => 'EMP-' . strtoupper(bin2hex(random_bytes(4))),
            'first_name' => trim((string)$data['first_name']),
            'last_name' => trim((string)$data['last_name']),
            'email' => strtolower(trim((string)$data['email'])),
            'password_hash' => password_hash((string)$data['password'], PASSWORD_DEFAULT),
            'role' => 'employee',
            'is_active' => true,
        ]);
        if (!$employees->save($employee)) {
            throw new UnprocessableEntityException('Your account could not be created.');
        }
        $this->request->getSession()->write('Auth.employee_id', $employee->id);
        return $this->json(['data' => $this->employeeData($employee), 'message' => 'Account created successfully.'], 201);
    }

    public function login(): \Cake\Http\Response
    {
        $this->request->allowMethod(['post']);
        $email = strtolower(trim((string)$this->request->getData('email')));
        $password = (string)$this->request->getData('password');
        if (!$email || !$password) {
            throw new BadRequestException('Email and password are required.');
        }
        $employee = TableRegistry::getTableLocator()->get('Employees')
            ->find()
            ->where(['email' => $email, 'is_active' => true])
            ->first();
        if (!$employee || !$employee->password_hash || !password_verify($password, $employee->password_hash)) {
            throw new UnauthorizedException('Email or password is incorrect.');
        }
        $this->request->getSession()->write('Auth.employee_id', $employee->id);
        return $this->json(['data' => $this->employeeData($employee), 'message' => 'Welcome back.']);
    }

    public function logout(): \Cake\Http\Response
    {
        $this->request->allowMethod(['post']);
        $this->request->getSession()->delete('Auth');
        return $this->json(['message' => 'You have been signed out.']);
    }

    public function me(): \Cake\Http\Response
    {
        return $this->json(['data' => $this->employeeData($this->currentEmployee())]);
    }
}
